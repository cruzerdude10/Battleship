﻿using System;

namespace Cruz_Battleship
{
    class Program
    {
        //global VARS
        public static string[,] _Ships = { { "B", "Battleship", "4" }, { "A", "Aircraft Carrier", "5" }, { "U", "Submarine", "3" }, { "D", "Destroyer", "3" }, { "S", "Small Ship", "2" } };
        public static char[] _letters = { '\0', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J' };
        public static string[,] playerOneShipBoard = new string[11, 11];
        public static string[,] playerTwoShipBoard = new string[11, 11];
        static void Main(string[] args)
        {
            //new boards
            playerOneShipBoard = GenerateCleanBoard();
            playerTwoShipBoard = GenerateCleanBoard();
            string[,] playerOneAttackBoard = GenerateCleanBoard();
            //player names
            Console.WriteLine("Player 1 Enter Username : ");
            string playerOneID = Console.ReadLine();
            Console.WriteLine("Player 2 Enter Username : ");
            string playerTwoID = Console.ReadLine();
            if (playerTwoID == "AI" || playerTwoID == "CPU")
            {
                Console.WriteLine("Beep Bop I dont feel like playing find a friend");
                Console.WriteLine("Player 2 Enter Username : ");
                playerTwoID = Console.ReadLine();
            }

            //Ship Placement -- Add OverLap Check in Placement Phase
            ReadyToClear($"Player {playerOneID} Ready? \nPress Any Key to Continue");
            ShipPlacementPhase(playerOneShipBoard, playerOneID);

            ReadyToClear($"Player {playerTwoID} Ready? \nPress Any Key to Continue");
            ShipPlacementPhase(playerTwoShipBoard, playerTwoID);

            //Shot Calling Phase
            //find way to store state of ships
            //Loop While Player 1 Still has ships || Player 2 still has ships
            //bool isPlayerTwoTurn = false
            //isPlayerTwoTurn = !isPlayerTwoTurn
        }//end main
        #region Board Tools
        static string[,] GenerateCleanBoard()
        {
            string[,] cleanBoard = new string[11, 11];
            string[] y_CoordLetter = { " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" };
            string[] x_CoordNumber = { " ", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            for (int x_Axis = 0; x_Axis < cleanBoard.GetLength(0); x_Axis++)
            {

                for (int y_Axis = 0; y_Axis < cleanBoard.GetLength(1); y_Axis++)
                {


                    if (x_Axis == 0)
                    {
                        cleanBoard[x_Axis, y_Axis] = y_CoordLetter[y_Axis];
                    }
                    else if (y_Axis == 0)
                    {
                        cleanBoard[x_Axis, y_Axis] = x_CoordNumber[x_Axis];

                    }
                    else
                    {
                        cleanBoard[x_Axis, y_Axis] = "W";
                    }

                }
            }

            return cleanBoard;
        }//end GenerateCleanBoard Function

        static void DisplayBoard(string[,] board)
        {
            for (int y_Axis = 0; y_Axis < board.GetLength(1); y_Axis++)
            {

                for (int x_Axis = 0; x_Axis < board.GetLength(0); x_Axis++)
                {
                    if (x_Axis == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                    }
                    else
                    {
                        ColorKey(board[x_Axis, y_Axis]);
                    }
                    Console.Write(board[x_Axis, y_Axis] + " ");
                }
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;
            }
        }//end function display board

        static void ColorKey(string symbol)
        {
            string[] numbers = { " ", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            string[] shipSymbols = { "B", "A", "U", "D", "S" };

            if (symbol == "W")
            {
                Console.ForegroundColor = ConsoleColor.Blue;
            }
            else if (symbol == "X")
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else if (symbol == "O")
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            for (int index = 0; index < numbers.Length; index++)
            {
                if (symbol == numbers[index])
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
            }
            for (int index = 0; index < shipSymbols.Length; index++)
            {
                if (symbol == shipSymbols[index])
                {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                }
            }

        }

        static string PrintMapKey()
        {

            while (true)
            {

                for (int index = 0; index <= _Ships.GetLength(0); index++)
                {
                    Console.WriteLine($"{index}: {_Ships[index, 1]}({_Ships[index, 0]})");
                }

            }
        }//end PlaceShips Function

        static void ReadyToClear(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ReadKey();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
        }
        #endregion

        static void ShipPlacementPhase(string[,] playerShipBoard, string playerID)
        {
            Console.WriteLine($"{playerID}'s Primary Grid");
            for (int shipID = 0; shipID < _Ships.GetLength(0); shipID++)
            {
                DisplayBoard(playerShipBoard);
                Console.WriteLine($"Ship : {_Ships[shipID, 1]}");
                Console.WriteLine($"Size : {_Ships[shipID, 2]}");

                //Get User Input for Coordinates
                int[,] coords = GetCoords(shipID);

                if (!CheckShipPlacement(playerShipBoard, coords))
                {
                    Console.WriteLine("Invalid Coords");
                    coords = GetCoords(shipID);
                }
                else
                {
                    PlaceShips(playerShipBoard, coords, shipID);
                }
            }
            Console.WriteLine();
            DisplayBoard(playerShipBoard);
        }

        static bool CheckShipCoord(string[,] board, int[] pointOfShip)
        {
            if (board[pointOfShip[0],pointOfShip[1]] != "W")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        
        static bool CheckShipPlacement(string[,] board, int[,] coords)
        {
            if (board[coords[0, 0], coords[0, 1]] != "W")
            {
                return false;
            }
            if (board[coords[1, 0], coords[1, 1]] != "W")
            {
                return false;
            }
            if (coords[0, 0] == coords[1, 0])//x coord are same
            {
                int count = coords[0, 1];
                if (coords[0, 1] < coords[1, 1])//Add to y axis
                {
                    while (count < coords[1, 1])
                    {
                        if (board[coords[0, 0], count] != "W")
                        {
                            return false;
                        }
                         
                        count++;
                    }
                }
                else if (coords[0, 1] > coords[1, 1])//subtract from y axis
                {
                    while (count > coords[1, 1])
                    {
                        if (board[coords[0, 0], count] != "W")
                        {
                            return false;
                        }
                        count--;
                    }
                }
            }
            else if (coords[0, 1] == coords[1, 1])//y coords are same
            {
                int count = coords[0, 0];
                if (coords[0, 0] < coords[1, 0])//Add to x axis
                {
                    while (count < coords[1, 0])
                    {
                        if (board[count, coords[0, 1]] != "W")
                        {
                            return false;
                        }
                        count++;
                    }
                }
                else if (coords[0, 0] > coords[1, 0])//subtract from x axis
                {
                    while (count > coords[1, 0])
                    {
                        if (board[count, coords[0, 1]] != "W")
                        {
                            return false;
                        }
                        count--;
                    }
                }
            }
            return true;
        }
        //updates board with placement of ship at given coords
        static void PlaceShips(string[,] board, int[,] coords, int shipID)
        {
            
            //place end peices
            board[coords[0, 0], coords[0, 1]] = _Ships[shipID, 0];
            board[coords[1, 0], coords[1, 1]] = _Ships[shipID, 0];
                
            //fill in peices between end points
            if (coords[0,0] == coords[1,0])//x coord are same
            {
                int count = coords[0, 1];
                if (coords[0,1] < coords[1,1])//Add to y axis
                {
                    while (count < coords[1,1])
                    {
                        board[coords[0, 0], count] = _Ships[shipID, 0];
                        count++;
                    }
                }
                else if (coords[0,1] > coords[1,1])//subtract from y axis
                {
                    while (count > coords[1,1])
                    {
                        board[coords[0, 0], count] = _Ships[shipID, 0];
                        count--;
                    }
                }
            }
            else if (coords[0,1] == coords[1,1])//y coords are same
            {
                int count = coords[0, 0];
                if (coords[0, 0] < coords[1, 0])//Add to x axis
                {
                    while (count < coords[1, 0])
                    {
                        board[count, coords[0,1]] = _Ships[shipID, 0];
                        count++;
                    }
                }
                else if (coords[0, 0] > coords[1,0])//subtract from x axis
                {
                    while (count > coords[1, 0])
                    {
                        board[count, coords[0,1]] = _Ships[shipID, 0];
                        count--;
                    }
                }
            }
            
            
        }
        //Returns Int equilvalent for a given Letter Coord, needs to be capitalized
        static int LetterToNumCoord(char letter)
        {
            
            for (int index = 1; index < _letters.Length; index++)
            {
                if (letter == _letters[index])
                {
                    return index;
                }
            }

            //else return -1 if letter isnt found
            return -1;
        }
        //Asks User for Ship Coords, Returns Array of Coords in proper format regardless of user input format (Letter(Num), Number)
        static int[,] GetCoords(int shipID)
        {
            Console.WriteLine();
            int[,] shipCoords = new int[2,2];
            string[] shipSideName = { "Bow", "Stern" };
            int[] bowPostion = new int[2]; //[0] = X, [1] = Y
            int[] sternPostion = new int[2];//[0] = X, [1] = Y
            int[,] possibleSternPos = new int[4, 2]; //[0] North(X,Y), [1] East(X,Y), [2] South(X,Y), [3] West(X,Y)

            for (int shipSide = 0; shipSide < shipSideName.Length; shipSide++)
            {
                //print Ship Name and Length
                if (shipSide == 0)
                {
                    Console.WriteLine($"{_Ships[shipID, 1]} ({_Ships[shipID, 2]})");
                }//end if

                //printing available coords
                if (shipSide == 1)
                {
                    //generate Possible Stern Postions
                    possibleSternPos = CoordInBounds(bowPostion, _Ships[shipID, 0]);
                    
                    //Print valid Stern Postions
                    for (int i = 0; i < possibleSternPos.GetLength(0); i++)
                    {

                        if (possibleSternPos[i, 0] != '\0')
                        {
                            Console.Write($"{possibleSternPos[i, 0]}{_letters[possibleSternPos[i, 1]]},    ");
                        }

                    }//end for
                    Console.WriteLine();
                }//end if

                //loops until valid coord is entered
                bool validCoord = false;
                while (!validCoord)
                {
                    //get ship Coords
                    Console.Write($"Enter {shipSideName[shipSide]} Coords (#,Letter): ");
                    string userCoord = Console.ReadLine().ToUpper();

                    //Sorts Coord String into array  {Number(x), letter(y)}
                    char firstChar = '\0';
                    char secondChar = '\0';
                    //Validates length of Coords
                    if (userCoord.Length == 2)
                    {
                        firstChar = userCoord[0];
                        secondChar = userCoord[1];
                    }
                    //if user enters anything at 10 validate and set proper values
                    if (userCoord.Length == 3)
                    {
                        if (userCoord[0] == '1' && userCoord[1] == '0')
                        {
                            firstChar = ':';//Value of 10 when ':' - '0'
                            secondChar = userCoord[2];
                        }
                    }

                    //check if user entered values in order, and fix it if they didnt
                    #region Convert and Assign Coords in proper location
                    //IF LEtter is first make letter postion[1]
                    if (firstChar - '@' > 0 && firstChar - '@' <= 10)
                    {
                        //check second char is number
                        if (secondChar - '0' > 0 && secondChar - '0' <= 10)
                        {
                            //set bow postion
                            if (shipSide == 0)
                            {
                                //set coords in proper array location
                                bowPostion[1] = LetterToNumCoord(userCoord[0]);
                                bowPostion[0] = (int)(userCoord[1] - '0');
                                //end loop
                                validCoord = true;
                            }//end if bow

                            //set stern Postion
                            if (shipSide == 1)
                            {
                                //check user input matches viable postions
                                for (int postions = 0; postions < possibleSternPos.GetLength(0); postions++)
                                {
                                    if (sternPostion[0] == possibleSternPos[postions, 0] && sternPostion[1] == possibleSternPos[postions, 1])
                                    {
                                        //set coords in proper array location
                                        sternPostion[1] = LetterToNumCoord(userCoord[0]);
                                        sternPostion[0] = (int)(userCoord[1] - '0');
                                        //end loop
                                        validCoord = true;
                                    }//end if
                                    else
                                    {
                                        Console.WriteLine("Invalid Coords");
                                    }//end else
                                }
                            }//end if stern
                        }//end if
                        else
                        {
                            Console.WriteLine("Invalid Coord Try Again.");
                        }

                    }//end if


                    //if number first make number postion[0]
                    else if (firstChar - '0' > 0 && firstChar - '0' <= 11)
                    {
                        //check if second char is letter
                        if (secondChar - '@' > 0 && secondChar - '@' <= 10)
                        {
                            //set bow
                            if (shipSide == 0)
                            {
                                //set coords in proper location
                                bowPostion[1] = LetterToNumCoord(secondChar);
                                bowPostion[0] = (int)(firstChar - '0');
                                //end loop
                                validCoord = true;
                            }//end if bow

                            //set stern
                            if (shipSide == 1)
                            {
                                //compare user input to valid stern postions
                                for (int postions = 0; postions < possibleSternPos.GetLength(0); postions++)
                                {
                                    //set Stern Coords in proper array locaiton
                                    sternPostion[1] = LetterToNumCoord(secondChar);
                                    sternPostion[0] = (int)(firstChar - '0');
                                    if (sternPostion[0] == possibleSternPos[postions, 0] && sternPostion[1] == possibleSternPos[postions, 1])
                                    {
                                        
                                        //end loop
                                        validCoord = true;
                                    }//end if
                                }//end for
                            }//end if stern
                        }
                        else
                        {
                            Console.WriteLine("Invalid Coord Try Again.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Coord Try Again.");
                    }
                    #endregion

                }//end while
            }//end for
            //set return bow
            shipCoords[0, 0] = bowPostion[0];//x
            shipCoords[0, 1] = bowPostion[1];//y
            //set return stern
            shipCoords[1, 0] = sternPostion[0];//x
            shipCoords[1, 1] = sternPostion[1];//y
            return shipCoords;
            
        }//end GetCoords function
        
        //returns Array of Possible Secondary Coords given first coords { N(XY), E(XY), S(XY), W(XY)}
        static int[,] CoordInBounds(int[] startingCoords, string ship)
        {
            int x_Coord = startingCoords[0];
            int y_Coord = startingCoords[1];
            int shipLength = 0;
            int[,] shipPostions = new int[4, 2];

            //find ship length by searching Ship ID
            for (int shipIndex = 0; shipIndex < _Ships.GetLength(0); shipIndex++)
            {
                if (ship == _Ships[shipIndex,0] || ship == _Ships[shipIndex,1])
                {
                    shipLength = int.Parse(_Ships[shipIndex, 2])-1;
                }
            }
            //check north bounds
            if (y_Coord > shipLength)
            {
                //Set X Coord
                shipPostions[0, 0] = x_Coord;

                //Set Y Coord
                shipPostions[0, 1] = y_Coord - shipLength;
            }
            //check east bounds
            if (x_Coord < 10 - shipLength)
            {
                //set X Coord
                shipPostions[1, 0] = x_Coord + shipLength;

                //Set Y Coord
                shipPostions[1, 1] = y_Coord;
            }
            //check south bounds
            if (y_Coord < 10 - shipLength)
            {
                //set X Coord
                shipPostions[2, 0] = x_Coord;

                //set Y Coord
                shipPostions[2, 1] = y_Coord + shipLength;
            }
            //check west
            if (x_Coord > shipLength)
            {
                //set x Coord
                shipPostions[3, 0] = x_Coord - shipLength;

                //set y coord
                shipPostions[3, 1] = y_Coord;
            }

            return shipPostions;
        }
    }//end class
}//end name
